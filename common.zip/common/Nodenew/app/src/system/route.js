import { Router, Link } from "@reach/router";

import Login from '../pages/login';
import Register from '../pages/register';
import Grid from '../components/grid/grid_bootstrap';
const  routes = (
    <Router>
      <Login path={"/signin"}/>
      <Register path={"/signup"}/>
      <Grid path={"/grid"}/>
    </Router>
)
export default routes;