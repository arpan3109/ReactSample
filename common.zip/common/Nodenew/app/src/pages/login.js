import React, { useState } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";

export default function Login() {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(event) {
    event.preventDefault();
    console.log("----password", password);
    console.log("----username", username);
    async function getValidation() {
      //   var data = { UserName: username, Password: password };
      //   var config = {
      //     method: "get",
      //     url: "http://10.17.3.142:8090/api/user",
      //     headers: {
      //       "Content-Type": "application/json",
      //     },
      //     data: data,
      //   };

      var data = JSON.stringify({ UserName: "ABC", Password: "abc" });

      var config = {
        method: "GET",
        url: "http://10.17.3.142:8090/api/user",
        headers: {
          "Content-Type": "application/json",
        },
        data: data,
      };

      //   axios(config)
      //     .then(function (response) {
      //       console.log(JSON.stringify(response.data));
      //     })
      //     .catch(function (error) {
      //       console.log(error);
      //     });

      await axios
        .post("http://10.17.3.142:8090/api/user", {
          UserName: username,
          Password: password,
        })
        .then(function (response) {
          console.log(response);
          if (response.data.result == true) {
            navigate("/grid");
          }
        })
        .catch(function (error) {
          console.log(error);
        });
    }
    getValidation();
  }

  return (
    <div className="Login container">
      <div className="row mt-5">
        <div className="col-sm-4"></div>
        <div className="col-sm-4">
          <div className="card">
            <div className="card-header">Login</div>
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label for="exampleFormControlInput1" className="form-label">
                    User Name
                  </label>
                  <input
                    className="form-control"
                    id="userName"
                    type="text"
                    value={username}
                    onChange={(e) => setUserName(e.target.value)}
                  />
                </div>

                <div className="mb-3">
                  <label for="exampleFormControlInput1" className="form-label">
                    Password
                  </label>
                  <input
                    className="form-control"
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>

                <button
                  block
                  size="lg"
                  type="submit"
                  className="btn btn-primary"
                >
                  Login
                </button>
              </form>
              <div className="card-footer mt-3 bg-transparent pr-0">
                <Link to="/signup" className=" pr-0 mt-2">
                  signup
                </Link>
              </div>
            </div>
          </div>
        </div>
        <div className="col-sm-4"></div>
      </div>
    </div>
  );
}
