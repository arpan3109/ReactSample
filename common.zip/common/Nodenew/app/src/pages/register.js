import React, { useState } from "react";
import axios from "axios";
import { Link, navigate } from "@reach/router";

export default function Login() {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");

  const handleSubmit = () => {
    async function addData() {
      var data = JSON.stringify({
        Email: "abc@gmail.com",
        Password: "204",
        UserName: "xyz",
      });

      var config = {
        method: "post",
        url: "http://10.17.3.142:8090/api/singup",
        headers: {
          "Content-Type": "application/json",
        },
        data: data,
      };
      await axios
        .post("http://10.17.3.142:8090/api/singup", {
          Email: email,
          Password: password,
          UserName: username,
        })
        .then(function (response) {
          console.log("-response--", response);
        })
        .catch(function (error) {
          console.log(error);
        });
    }
    addData();
    // if (username.length && password.length && email.length) {
    //   alert("------ in ");
    //   const data = {
    //     username: username,
    //     password: password,
    //     email: email,
    //   };
    //   axios
    //     .post("/register", data)
    //     .then(function (response) {
    //       console.log("----response", response);
    //       navigate("/grid");
    //     })
    //     .catch(function (error) {
    //       console.log(error);
    //     });
    // } else {
    //   setMessage("Please enter valid data");
    // }
  };
  return (
    <div className="Login container">
      <div className="row mt-5">
        <div className="col-sm-4"></div>
        <div className="col-sm-4">
          <div className="card">
            <div className="card-header">Register Now</div>
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">User Name</label>
                  <input
                    className="form-control"
                    type="text"
                    value={username}
                    onChange={(e) => setUserName(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Email</label>
                  <input
                    className="form-control"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Password</label>
                  <input
                    className="form-control"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Signup
                </button>
              </form>
              <div className="card-footer mt-3 bg-transparent pr-0">
                <Link to="/signin" className=" text-danger pr-0 mt-2">
                  login
                </Link>
              </div>
            </div>
          </div>
        </div>
        <div className="col-sm-4"></div>
      </div>
    </div>
  );
}
