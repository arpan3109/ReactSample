import React from 'react';
import{shallow,configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Login from './login';

configure({adapter: new Adapter()});
describe('<Login/>', ()=>{
    let wrapper
    beforeEach(()=>{
        wrapper = shallow(<Login/>)
    })

    it ('hase an input feild',()=>{
        
        const input  = wrapper.find('#userName')
        // console.log("-------------");
        // console.log(wrapper.debug())
        // console.log("-------------");
        expect(input.props().type).toBe("text")
    } )
    it('contain a button',()=>{
        // let wrapper = shallow(<Login/>)
        const button  = <button
        block
        size="lg"
        type="submit"
        className="btn btn-primary"
      >
        Login
      </button>
      expect(wrapper.containsMatchingElement(button)).toBe(true)
    })
})