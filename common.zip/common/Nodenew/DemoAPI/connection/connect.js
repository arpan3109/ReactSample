var sql = require("mssql");
var connect = function () {
  var conn = new sql.ConnectionPool({
    // user: "sa",
    // password: "Pass@123",
    // server: "SAI-PC",
    // database: "TESTDB",
    user: "Sample",
    password: "Test@2021",
    sever: "STEMS-WKS2148",
    database: "TestDB",
  });

  return conn;
};

module.exports = connect;
