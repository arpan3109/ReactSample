var Db = require("./dboperations");
var Order = require("./order");
const dboperations = require("./dboperations");

var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var app = express();
var router = express.Router();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use("/api", router);

app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  console.log("middleware");
  next();
});
// router.use((request, response, next) => {
//   console.log("middleware");
//   next();
// });

router.route("/users").get((request, response) => {
  dboperations.getUsers().then((result) => {
    response.json(result[0]);
  });
});

router.route("/user").post((request, response) => {
  let order = { ...request.body };
  console.log("request.body--", order);
  dboperations.getUser(order).then((result) => {
    let abc = result[0];
    console.log("abc-- ", abc.length);
    //  response.json(result[0]);
    if (abc.length > 0) {
      response.status(201).json({ result: true });
    } else {
      response.status(201).json({ result: false });
    }
    //  response.status(201).json({ result: true });
  });
});

router.route("/singup").post((request, response) => {
  let order = { ...request.body };
  console.log("request.body--", order);
  dboperations.addUser(order).then((result) => {
    response.status(201).json({ result: "data inserted" });
  });
});

var port = process.env.PORT || 8090;
app.listen(port);
console.log("Order API is runnning at " + port);
