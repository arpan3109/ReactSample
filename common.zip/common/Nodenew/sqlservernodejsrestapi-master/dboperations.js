var config = require("./dbconfig");
const sql = require("mssql");

async function getUsers() {
  try {
    let pool = await sql.connect(config);
    let products = await pool.request().query("SELECT * FROM LoginsData");
    return products.recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function getUser(order) {
  try {
    console.log("order--", order);
    let pool = await sql.connect(config);
    let product = await pool
      .request()
      .input("Password", sql.NVarChar, order.Password)
      .input("UserName", sql.NVarChar, order.UserName)
      .query(
        "select * from LoginsData where UserName =@UserName and Password = @Password"
      );
    return product.recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function addUser(order) {
  try {
    let pool = await sql.connect(config);
    let insertProduct = await pool
      .request()
      .input("EmailID", sql.NVarChar, order.Email)
      .input("Password", sql.NVarChar, order.Password)
      .input("UserName", sql.NVarChar, order.UserName)
      .query(
        "INSERT INTO LoginsData (UserName,EmailID, Password) VALUES (@UserName, @EmailID,@Password)"
      );
    return insertProduct.recordsets;
  } catch (err) {
    console.log(err);
  }
}

module.exports = {
  getUsers: getUsers,
  getUser: getUser,
  addUser: addUser,
};
