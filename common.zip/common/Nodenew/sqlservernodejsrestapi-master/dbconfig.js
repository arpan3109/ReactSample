const config = {
  user: "Sample",
  password: "Test@2021",
  server: "127.0.0.1",
  database: "TestDB",
  options: {
    trustedconnection: true,
    enableArithAbort: true,
    instancename: "STEMS-WKS2148",
  },
  port: 1433,
};

module.exports = config;
