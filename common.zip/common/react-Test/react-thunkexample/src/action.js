import axios from "axios";

export const fetchPosts = () => async (dispatch, getState) => {
  dispatch({ type: "FETCH_POSTS_REQUEST" });
  try {
    const response = await axios.get(
      "https://jsonplaceholder.typicode.com/posts"
    );
    console.log("response", response.data);
    dispatch({ type: "FETCH_POSTS_SUCCESS", payload: response.data });
  } catch (error) {
    console.log("error", error);
    dispatch({ type: "FETCH_POSTS_FAILURE", error: error });
  }
};

// export const fetchPosts = () => async (dispatch, getState) => {
//   const response = await axios.get(
//     "https://jsonplaceholder.typicode.com/posts"
//   );
//   console.log("response", response.data);

//   dispatch({ type: "FETCH_POSTS_SUCCESS", payload: response.data });
// };

// export const fetchPosts = () => {
//   const promise = axios.get("https://jsonplaceholder.typicode.com/posts");
//   return { type: "FETCH_USER", payLoad: promise };
// };
