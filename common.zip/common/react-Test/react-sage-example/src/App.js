import './App.css';
import Users from './components/UserComponents'

function App() {
  return (
    <div className="App">
      <Users/>
    </div>
  );
}

export default App;
