export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";
export const SUBSTRACT = "SUBSTRACT";
export const ADD = "ADD";
export const STORE_RESULT = "STORE_RESULT";
export const DELETE_RESULT = "DELETE_RESULT";
