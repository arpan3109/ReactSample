import React from "react";
import BestSeller from "./components/bestSeller";
import BookBlock from "./components/bookBlock.jsx";
import CarouselBook from "./components/carousel";
import { apiGetRequest } from "./functions/bookFuntions";

const API = `http://localhost:82/api/books/`;
class App extends React.Component {
  apiGetRequest = apiGetRequest.bind(this);
  constructor(params) {
    super(params);
    this.state = {
      books: [],
    };
  }
  componentDidMount() {
    this.apiGetRequest(API);
  }
  render() {
    console.log(this.state);
    return (
      <main className="container">
        {/* <BestSeller></BestSeller> */}
        <CarouselBook books={this.state.books}></CarouselBook>
        <div className="row mb-2">
          {this.state.books.length &&
            this.state.books.map((book) => (
              <BookBlock key={book.id} book={book}></BookBlock>
            ))}
        </div>
      </main>
    );
  }
}

export default App;
