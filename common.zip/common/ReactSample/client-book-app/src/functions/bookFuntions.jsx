import React from "react";
import axios from "axios";

export const apiGetRequest = function (API) {
  console.log("apiGetRequest");
  axios
    .get(API)
    .then((res) => {
      const books = res.data;
      this.setState({ books: books });
      //   this.setState({ keys: Object.keys(this.state.books[0]) });
    })
    .catch((error) => {
      this.errorHandler(error);
    });
};
