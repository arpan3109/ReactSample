import React, { Component } from "react";
import {
  Accordion,
  Badge,
  Button,
  Col,
  Navbar,
  Nav,
  NavDropdown,
  NavLink,
} from "react-bootstrap";
import Card from "react-bootstrap/Card";
import { Link } from "react-router-dom";
import { Row } from "reactstrap";
import { withRouter, Redirect } from "react-router-dom";

export class Counter extends Component {
  static displayName = Counter.name;

  constructor(props) {
    super(props);
    this.state = { currentCount: 0, redirect: false };
    this.incrementCounter = this.incrementCounter.bind(this);
  }

  incrementCounter() {
    this.setState({
      currentCount: this.state.currentCount + 1,
    });
  }
  setRedirect = () => {
    this.setState({
      redirect: true,
    });
  };
  renderRedirect = () => {
    if (this.state.redirect) {
      return <Redirect to="/" />;
    }
  };
  render() {
    const FancyButton = React.forwardRef((props, ref) => (
      <button ref={ref} className="btn btn-outline-success">
        {props.children}
      </button>
    ));

    const ref = React.createRef();
    return (
      <>
        <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
          <Navbar.Brand href="#home">React-Bootstrap</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="#features">Features</Nav.Link>
              <Nav.Link tag={Link} to="/counter">
                Pricing
              </Nav.Link>
              <NavDropdown title="Dropdown" id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">
                  Another action
                </NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">
                  Something
                </NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">
                  Separated link
                </NavDropdown.Item>
              </NavDropdown>
            </Nav>
            <Nav>
              <Nav.Link href="#deets">More deets</Nav.Link>
              <Nav.Link eventKey={2} href="#memes">
                Dank memes
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        <div>
          <h1>Counter</h1>
          <p>This is a simple example of a React component.</p>
          <p aria-live="polite">
            Current count: <strong>{this.state.currentCount}</strong>
          </p>
          {this.renderRedirect()}
          <button className="btn btn-primary" onClick={this.setRedirect}>
            Increment
          </button>
          <Accordion defaultActiveKey="0">
            <Card>
              <Accordion.Toggle as={Card.Header} eventKey="0">
                Click me!
              </Accordion.Toggle>
              <Accordion.Collapse eventKey="0">
                <Card.Body>Hello! I'm the body that you clicked one</Card.Body>
              </Accordion.Collapse>
            </Card>
            <Card>
              <Accordion.Toggle as={Card.Header} eventKey="1">
                Click me!
              </Accordion.Toggle>
              <Accordion.Collapse eventKey="1">
                <Card.Body>Hello! I'm another body</Card.Body>
              </Accordion.Collapse>
            </Card>
          </Accordion>
          <Row>
            <Col sm={2}>
              <Button variant="primary">
                Profile <Badge variant="light">9</Badge>
                <span className="sr-only">unread messages</span>
              </Button>
            </Col>
            <Col sm={2}>
              <Badge variant="primary">Primary</Badge>{" "}
            </Col>
          </Row>
          <FancyButton ref={ref}>Click me!</FancyButton>
        </div>
      </>
    );
  }
}
