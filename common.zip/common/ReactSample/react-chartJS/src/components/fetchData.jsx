import React, { Component } from "react";
import { connect } from "react-redux";
import { booksRecord } from "../redux/actions";
import { useHistory } from "react-router-dom";
import { withRouter, Redirect } from "react-router-dom";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import { Line } from "react-chartjs-2";

class FetchData extends Component {
  static displayName = FetchData.name;
  constructor(props) {
    super(props);
    this.state = {
      books: [],
      columns: [],
      loading: true,
      redirect: false,
      dataChart: {},
    };
    // this.handleClick = this.handleClick.bind(this);
  }

  // setRedirect = () => {
  //   this.setState({
  //     redirect: true,
  //   });
  // };
  // renderRedirect = () => {
  //   if (this.state.redirect) {
  //     return <Redirect to="/target" />;
  //   }
  // };
  // handleClick(id) {
  //   const history = withRouter();
  //   history.push(`/book/${id}`);
  //   const pathroute = `/book/${id}`;
  //   return <Redirect to="/" />;
  // }

  componentDidMount() {
    this.populateWeatherData();
    const data = {
      labels: ["January", "February", "March", "April", "May", "June", "July"],
      datasets: [
        {
          label: "My First dataset",
          fill: false,
          lineTension: 0.1,
          backgroundColor: "rgba(75,192,192,0.4)",
          borderColor: "rgba(75,192,192,1)",
          borderCapStyle: "butt",
          borderDash: [],
          borderDashOffset: 0.0,
          borderJoinStyle: "miter",
          pointBorderColor: "rgba(75,192,192,1)",
          pointBackgroundColor: "#fff",
          pointBorderWidth: 1,
          pointHoverRadius: 5,
          pointHoverBackgroundColor: "rgba(75,192,192,1)",
          pointHoverBorderColor: "rgba(220,220,220,1)",
          pointHoverBorderWidth: 2,
          pointRadius: 1,
          pointHitRadius: 5,
          data: [65, 59, 80, 81, 56, 55, 40],
        },
        {
          label: "My Second dataset",
          fill: false,
          lineTension: 0.1,
          backgroundColor: "rgba(75,192,192,0.4)",
          borderColor: "rgba(255, 0, 0)",
          borderCapStyle: "butt",
          borderDash: [],
          borderDashOffset: 0.0,
          borderJoinStyle: "miter",
          pointBorderColor: "rgba(255, 0, 0)",
          pointBackgroundColor: "#fff",
          pointBorderWidth: 1,
          pointHoverRadius: 5,
          pointHoverBackgroundColor: "rgba(255, 0, 0)",
          pointHoverBorderColor: "rgba(220,220,220,1)",
          pointHoverBorderWidth: 2,
          pointRadius: 1,
          pointHitRadius: 5,
          data: [60, 54, 75, 76, 51, 50, 35],
        },
      ],
    };
    this.setState({ dataChart: data });
    this.rowEvent = {
      onClick: (e, row, rowIndex) => {
        {
          this.setState({
            redirect: true,
          });
        }
      },
    };
    const columns = [
      {
        dataField: "id",
        text: "ID",
        // events: {
        //   onClick: (e, column, columnIndex, row, rowIndex) => {
        //     console.log(row);
        //     return this.setRedirect;
        //   },
        // },
        options: {
          onRowClick: function (row) {
            console.log("on row click " + row);
          },
        },
      },

      { dataField: "bookName", text: "Book Name", sort: true },
      { dataField: "price", text: "Price", sort: true },
      { dataField: "category", text: "Category", sort: true },
      { dataField: "author", text: "Author", sort: true },
    ];
    this.setState({ columns, loading: false });
  }

  static renderForecastsTable(books) {
    return null;
  }

  renderRedirect = () => {
    if (this.state.redirect) {
      return <Redirect to="/" />;
    }
  };
  setRedirect = () => {
    this.setState({
      redirect: true,
    });
  };

  render() {
    console.log(this.props.books);

    // const CaptionElement = () => (
    //   <h3
    //     style={{
    //       borderRadius: "0.25em",
    //       textAlign: "center",
    //       color: "purple",
    //       border: "1px solid purple",
    //       padding: "0.5em",
    //     }}
    //   >
    //     Component as Header
    //   </h3>
    // );

    const options = {
      // pageStartIndex: 0,
      sizePerPage: 5,
      hideSizePerPage: true,
      hidePageListOnlyOnePage: true,
    };
    const defaultSorted = [
      {
        dataField: "bookName",
        order: "desc",
      },
    ];
    let contents = this.state.loading ? (
      <p>
        <em>Loading...</em>
      </p>
    ) : (
      // FetchData.renderForecastsTable(this.state.books)
      <>
        {this.renderRedirect()}
        <BootstrapTable
          bootstrap4
          striped
          hover
          keyField="id"
          data={this.props.books}
          // caption={<CaptionElement />}
          columns={this.state.columns}
          selectRow={this.selectRow}
          defaultSorted={defaultSorted}
          pagination={paginationFactory(options)}
        ></BootstrapTable>
        <div>
          <h2>Line Example</h2>
          <Line data={this.state.dataChart} />
        </div>
      </>
    );

    return (
      <div>
        <h1 id="tabelLabel">Book Details</h1>
        <p>This component demonstrates fetching data from the server.</p>
        {this.renderRedirect()}
        {contents}
      </div>
    );
  }

  async populateWeatherData() {
    try {
      const response = await fetch("http://localhost:63577/api/books");
      const data = await response.json();
      console.log(data);
      this.setState({ books: data, loading: false });
      this.props.booksRecord(data);
    } catch (error) {
      console.log(error);
    }
  }
}

export const getTodosState = (store) => store.books;

export const getTodoList = (store) =>
  getTodosState(store) ? getTodosState(store).allBooksData : [];

export const getTodoById = (store, id) =>
  getTodosState(store) ? { ...getTodosState(store).byIds[id], id } : {};

export const getTodos = (store) =>
  getTodoList(store).map((id) => getTodoById(store, id));

const mapStateToProps = function (state) {
  const books = getTodoList(state);
  return { books };
};

export default connect(mapStateToProps, { booksRecord })(FetchData);
