import React, { Component } from "react";

class BookId extends Component {
  constructor(params) {
    super(params);
    this.state = {
      book: "",
      loading: true,
    };
  }
  componentDidMount() {
    this.populateWeatherData();
  }
  async populateWeatherData() {
    try {
      const response = await fetch(
        `http://localhost:63577/api/books/${this.props.match.params.id}`
      );
      const data = await response.json();
      console.log(data);
      this.setState({ book: JSON.stringify(data), loading: false });
      // this.props.booksRecord(data);
    } catch (error) {
      console.log(error);
    }
  }
  render() {
    let contents = this.state.loading ? (
      <p>
        <em>Loading...</em>
      </p>
    ) : (
      <div>{this.state.book}</div>
    );
    return <div>{contents}</div>;
  }
}

export default BookId;
