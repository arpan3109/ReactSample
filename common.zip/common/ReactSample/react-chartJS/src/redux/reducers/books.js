const initialSate = { allBooksData: [], byIds: {} };
export default function (state = initialSate, action) {
  switch (action.type) {
    case "ADD_BOOK": {
      // const { content } = action.payload;
      return {
        ...state,
        allBooksData: [...state.allBooksData],
      };
    }
    case "BOOKS_RECORD": {
      const { content } = action.payload;
      return {
        ...state,
        allBooksData: content,
        // byIds: { ...state.byIds, content },
      };
    }
    default:
      return state;
  }
}
