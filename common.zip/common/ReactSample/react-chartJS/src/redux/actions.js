export const booksRecord = (content) => ({
  type: "BOOKS_RECORD",
  payload: {
    content,
  },
});
