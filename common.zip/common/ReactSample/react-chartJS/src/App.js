import React, { Component } from "react";
import { Route } from "react-router";
import { Layout } from "./components/layout";
import { Home } from "./components/home";
import FetchData from "./components/fetchData";
import { Counter } from "./components/counter";
import BookId from "./components/book";
import "./css/custom.css";

class App extends Component {
  render() {
    return (
      <Layout>
        <Route exact path="/" component={Home} />
        <Route path="/counter" component={Counter} />
        <Route path="/fetch-data" component={FetchData} />
        <Route path="/book/:id" component={BookId} />
      </Layout>
    );
  }
}

export default App;
