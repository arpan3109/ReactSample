import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import "./App.css";

const dropDownRequestBodyJson = {
  searchText: "",
  maxCount: 50,
  skipCount: 0,
  application: 0,
  typeID: 19,
  fieldID: 1190,
  parentValues: {
    0: ["0"],
  },
  username: "",
};
const useStyles = makeStyles((theme) => ({
  root: {
    "& .MuiTextField-root": {
      margin: theme.spacing(1),
      width: "25ch",
    },
  },
}));

export default function App() {
  const classes = useStyles();
  const api = "http://localhost:63577/weatherforecast/";
  const [caseIDResponse, setCaseIDResponse] = useState({});
  useEffect(() => {
    axios.post(api).then((res) => {
      console.log("details data api --- " + res.data.responseContent.details);
      setDropDownRequestBody({
        ...dropDownRequestBody,
        ["typeID"]: res.data.responseContent.typeId,
      });
      setCaseIDResponse(res.data.responseContent);
      setDetails(res.data.responseContent.details);
      res.data.responseContent.details.map((detail) => {
        if (
          detail.controlTypeCode === "D" ||
          detail.controlTypeCode === "E" ||
          detail.controlTypeCode === "O"
        ) {
          if(detail.externalDatasourceId>0){
            if(detail.cascadeItems.length>0){
              const superParent = true;
              detail.cascadeItems.map((cascadeItem)=>{
                if(cascadeItem.childTypeId === detail.controlId){
                  superParent = false;
                }
              })
              if(superParent){
                setDropDownRequestBody({
                  ...dropDownRequestBody,
                  ["fieldID"]: controlId,
                });
                axios.post(api + "dropdown", dropDownRequestBody).then((res) => {
                      
                      let detailsData = [...details];
                      let index = detailsData.findIndex((temp) => temp.id === detail.id);
                      detailsData[index] = {...detailsData[index],"responseContent":res.data.responseContent};
                });
              }
            }
          }
        }
    });
  }, [JSON.stringify(details)]);
  const [details, setDetails] = useState([]);
  const [dropDown, setDropdown] = useState([]);
  const [dropDownRequestBody, setDropDownRequestBody] = React.useState(
    dropDownRequestBodyJson
  );

  const handleChange = (event) => {
    console.log("eventevent ", event);
    console.log("event.target.name ", event.target.name);
    console.log("event.target.value ", event.target.value);
  };

  return (
    <form className={classes.root} noValidate autoComplete="off">
      <div>
        {details.map((detail) => {
          // console.log(detail.controlTypeCode);
          if (
            detail.controlTypeCode === "D" ||
            detail.controlTypeCode === "E" ||
            detail.controlTypeCode === "O"
          ) {
            // console.log("detail.controlTypeCode", detail.controlTitle);
            return (
              <TextField
                id="standard-select-currency"
                select
                label="Select"
                name={detail.controlTitle}
                // value={detail.externalDatasourceObjectId}
                onChange={handleChange}
                helperText={detail.controlId}
                key={detail.id}
              >
                {currencies.map((option) => (
                  <MenuItem
                    key={option.value}
                    value={option.value}
                    key={option.value}
                  >
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
            );
          }
        })}
      </div>
    </form>
  );
}