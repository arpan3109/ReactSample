import * as actions from "../../actionType";
const initialSate = { books: [], byIds: {} };
export default function (state = initialSate, action) {
  switch (action.type) {
    case actions.ADD_BOOK: {
      // const { content } = action.payload;
      return {
        ...state,
        books: [...state.books],
      };
    }
    case actions.BOOKS_RECORD: {
      const { content } = action.payload;
      return {
        ...state,
        books: content,
        // byIds: { ...state.byIds, content },
      };
    }
    default:
      return state;
  }
}
