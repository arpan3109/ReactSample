import { combineReducers } from "redux";
import bookLibrary from "./bookLibrary";

export default combineReducers({ bookLibrary });
