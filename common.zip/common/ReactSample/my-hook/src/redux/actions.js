import * as actions from "../actionType";

export const booksRecord = (content) => ({
  type: actions.BOOKS_RECORD,
  payload: {
    content,
  },
});
