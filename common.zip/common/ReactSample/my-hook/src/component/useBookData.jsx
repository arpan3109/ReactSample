import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { booksRecord } from "../redux/actions.js";
import axios from "axios";

export function useBookData(API) {
  const diapatch = useDispatch();
  const sampleData = useSelector((state) => state);
  const [books, setbooks] = useState([]);

  useEffect(() => {
    console.log("data");
    async function populateBookData() {
      try {
        const response = await fetch(API);
        const data = await response.json();
        console.log(data);
        diapatch(booksRecord(data));
        setbooks(data);
      } catch (error) {
        console.log(error);
      }
    }
    populateBookData();
    // console.log("apiGetRequest");
    // axios
    //   .get(API)
    //   .then((res) => {
    //     const books = res.data;
    //     console.log(books);
    //     diapatch(booksRecord(books));
    //     setbooks(books);
    //   })
    //   .catch((error) => {
    //     this.errorHandler(error);
    //   });
  }, [JSON.stringify(books)]);

  const [update, setUpdate] = useState({});

  useEffect(() => {
    // const [books, setbooks] = useState([]);
    console.log(update);

    update.id &&
      axios
        .put(API + update.id, update)
        .then((res) => {
          console.log("put response successfull with data " + res.data);
          let data = [...books];
          let index = data.findIndex((book) => book.id === update.id);
          data[index] = update;
          setbooks(data);
          // diapatch(booksRecord(data));
        })
        .catch((err) => {
          console.log(err);
        });
  }, [JSON.stringify(update)]);

  return [books, setbooks, setUpdate];
}

// handleUpdateClick = (bookData) => {
//   this.triggerChildAlert();
//   console.log(bookData);
//   axios
//     .put(API + bookData.id, bookData)
//     .then((res) => {
//       console.log("put response successfull with data " + res.data);
//       this.disabledOnCreateUpdateDelete();
//       this.apiGetRequest(API);
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// };
