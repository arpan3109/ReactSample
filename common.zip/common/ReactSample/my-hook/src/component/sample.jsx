import React from "react";
import { useSelector } from "react-redux";
import { useBookData } from "./useBookData";

export default function Sample(params) {
  const [booksData, setBooksData] = useBookData(params.API);
  const bookData = useSelector((state) => state);
  console.log(bookData.bookLibrary.books);
  return (
    <>
      <hr></hr>
      <div className="App">
        {/* <div>{sample.id}</div> */}

        {bookData.bookLibrary.books.map((book) => (
          <div key={book.id}>{book.bookName}</div>
        ))}
      </div>
    </>
  );
}
