import React from "react";
import { useState, useEffect } from "react";
import "./App.css";
import { useBookData } from "./component/useBookData";
import { useSelector, useDispatch } from "react-redux";
import { booksRecord } from "./redux/actions";
import Sample from "./component/sample";
import axios from "axios";
const API = "http://10.17.3.182:82/api/books";
// const API = "http://localhost:5000/api/books/";

function App() {
  const [booksData, setBooksData, setBookUpdate] = useBookData(API);
  // const [booksData, setBooksData] = useState([]);

  // useEffect(() => {
  //   console.log("data");
  //   console.log(booksData);
  //   async function populateBookData() {
  //     try {
  //       const response = await fetch(API);
  //       const data = await response.json();
  //       console.log(JSON.stringify(data));
  //       setBooksData(data);
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   }
  //   populateBookData();
  // }, [JSON.stringify(booksData)]);
  console.log("notes booksData " + booksData);
  // const dispatch = useDispatch();
  // const booksRecordData = (booksData) => dispatch(booksRecord(booksData));

  const notes = useSelector((state) => state);
  console.log(
    "notes.bookLibrary.books -- " + JSON.stringify(notes.bookLibrary.books)
  );

  const myObjStr = JSON.stringify(booksData);
  const sample = booksData[1];
  const updateData = {
    id: "5f07276005488f4008ee8472",
    bookName: "Stemmons pvt test",
    price: 140,
    category: "General",
    author: "nishant pradhan",
  };

  const newData = {
    bookName: "Same data use",
    price: 78,
    category: "General",
    author: "human",
  };

  function handleUpdateClick(bookData) {
    axios
      .put(API + bookData.id, bookData)
      .then((res) => {
        console.log("put response successfull with data " + res.data);
        let books = [...booksData];
        let index = books.findIndex((book) => book.id === bookData.id);
        const changeData = {
          id: "5f07276005488f4008ee8472",
          bookName: "time set",
          price: 899,
          category: "General",
          author: "nishant pradhan",
        };
        books[index] = {
          ...books[index],
          bookName: "Stemmons pvt ltd",
          price: 88,
          category: "public",
          author: "human",
        };
        console.log(books[index]);
        books[index] = changeData;
        console.log(books[index]);
        setBooksData(books);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  function handleCreateClick(newBookObject) {
    axios
      .post(API, newBookObject)
      .then((res) => {
        console.log("create response successfull with data " + res.data);
        setBooksData([...booksData, newBookObject]);
        console.log("booksData " + booksData.length);
        // booksRecordData(booksData);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  return (
    <>
      <div className="App">
        <div onClick={() => handleCreateClick(newData)}>
          {JSON.stringify(sample)}
        </div>

        {/* <div>{sample.id}</div> */}

        {booksData.map((book) => (
          <div key={book.id} onClick={() => setBookUpdate(updateData)}>
            {book.bookName}
          </div>
        ))}
      </div>
      <Sample API={API} books={booksData} />
    </>
  );
}

export default App;
