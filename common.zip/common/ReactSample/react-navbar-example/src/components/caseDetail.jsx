import React, { Component } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";
import CaseDetailCommentLists from "./caseDetailCommentLists";
import Grid from "@material-ui/core/Grid";
import CaseDetailBasicInfo from "./caseDetailBasicInfo";

const useStyles = makeStyles({
  root: {
    minWidth: 275,
  },
  bullet: {
    display: "inline-block",
    margin: "0 2px",
    transform: "scale(0.8)",
  },
  title: {
    fontSize: 16,
  },
  pos: {
    marginBottom: 12,
  },
  dividersty: {
    marginBottom: "1rem",
  },
  fixedHeight: {
    height: "60vh",
    overflow: "auto",
  },
});

export default function CaseDetails() {
  const classes = useStyles();
  return (
    <>
      <Grid container spacing={1}>
        {/* Chart */}
        <Grid item xs={12} sm={6} md={4} lg={9}>
          <Typography
            className={classes.title}
            color="textSecondary"
            gutterBottom
          >
            Software-Dev
          </Typography>
          <Typography variant="h3" component="h2">
            Let me get the cheese feom the fridge
          </Typography>
          <Divider className={classes.dividersty} />
          <div className={classes.fixedHeight}>
            <CaseDetailCommentLists />
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={8} lg={3}>
          <CaseDetailBasicInfo />
        </Grid>
      </Grid>
    </>
  );
}
