import React, { Component } from "react";
import { connect } from "react-redux";
import { booksRecord } from "../redux/actions";
import { useHistory } from "react-router-dom";
import { withRouter, Redirect } from "react-router-dom";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";

class FetchData extends Component {
  static displayName = FetchData.name;
  constructor(props) {
    super(props);
    this.state = {
      books: [],
      columns: [],
      loading: true,
      redirect: false,
    };
    // this.handleClick = this.handleClick.bind(this);
  }

  // setRedirect = () => {
  //   this.setState({
  //     redirect: true,
  //   });
  // };
  // renderRedirect = () => {
  //   if (this.state.redirect) {
  //     return <Redirect to="/target" />;
  //   }
  // };
  // handleClick(id) {
  //   const history = withRouter();
  //   history.push(`/book/${id}`);
  //   const pathroute = `/book/${id}`;
  //   return <Redirect to="/" />;
  // }

  componentDidMount() {
    this.populateWeatherData();
    this.rowEvent = {
      onClick: (e, row, rowIndex) => {
        {
          this.setState({
            redirect: true,
          });
        }
      },
    };
    const columns = [
      {
        dataField: "id",
        text: "ID",
        // events: {
        //   onClick: (e, column, columnIndex, row, rowIndex) => {
        //     console.log(row);
        //     return this.setRedirect;
        //   },
        // },
        options: {
          onRowClick: function (row) {
            console.log("on row click " + row);
          },
        },
      },

      { dataField: "bookName", text: "Book Name", sort: true },
      { dataField: "price", text: "Price", sort: true },
      { dataField: "category", text: "Category", sort: true },
      { dataField: "author", text: "Author", sort: true },
    ];
    this.setState({ columns, loading: false });
  }

  static renderForecastsTable(books) {
    return null;
  }

  renderRedirect = () => {
    if (this.state.redirect) {
      return <Redirect to="/" />;
    }
  };
  setRedirect = () => {
    this.setState({
      redirect: true,
    });
  };

  render() {
    console.log(this.props.books);
    // const CaptionElement = () => (
    //   <h3
    //     style={{
    //       borderRadius: "0.25em",
    //       textAlign: "center",
    //       color: "purple",
    //       border: "1px solid purple",
    //       padding: "0.5em",
    //     }}
    //   >
    //     Component as Header
    //   </h3>
    // );

    const options = {
      // pageStartIndex: 0,
      sizePerPage: 5,
      hideSizePerPage: true,
      hidePageListOnlyOnePage: true,
    };
    const defaultSorted = [
      {
        dataField: "bookName",
        order: "desc",
      },
    ];
    let contents = this.state.loading ? (
      <p>
        <em>Loading...</em>
      </p>
    ) : (
      // FetchData.renderForecastsTable(this.state.books)
      <>
        {this.renderRedirect()}
        <BootstrapTable
          bootstrap4
          striped
          hover
          keyField="id"
          data={this.props.books}
          // caption={<CaptionElement />}
          columns={this.state.columns}
          selectRow={this.selectRow}
          defaultSorted={defaultSorted}
          pagination={paginationFactory(options)}
        ></BootstrapTable>
      </>
    );

    return (
      <div>
        <h1 id="tabelLabel">Book Details</h1>
        <p>This component demonstrates fetching data from the server.</p>
        {this.renderRedirect()}
        {contents}
      </div>
    );
  }

  async populateWeatherData() {
    try {
      const response = await fetch("http://10.17.3.182:82/api/books");
      const data = await response.json();
      console.log(data);
      this.setState({ books: data, loading: false });
      this.props.booksRecord(data);
    } catch (error) {
      console.log(error);
    }
  }
}

export const getTodosState = (store) => store.books;

export const getTodoList = (store) =>
  getTodosState(store) ? getTodosState(store).allBooksData : [];

export const getTodoById = (store, id) =>
  getTodosState(store) ? { ...getTodosState(store).byIds[id], id } : {};

export const getTodos = (store) =>
  getTodoList(store).map((id) => getTodoById(store, id));

const mapStateToProps = function (state) {
  const books = getTodoList(state);
  return { books };
};

export default connect(mapStateToProps, { booksRecord })(FetchData);
