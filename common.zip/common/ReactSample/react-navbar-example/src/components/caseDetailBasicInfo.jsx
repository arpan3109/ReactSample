import React, { Component } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";
import Avatar from "@material-ui/core/Avatar";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import ss from "./ArpanD.jpg";

const useStyles = makeStyles((theme) => ({
  root: {
    paddingLeft: theme.spacing(4),
  },
  title: {
    fontSize: 16,
    fontWeight: "550",
  },
  avatar: {
    border: "2px solid #eee",
  },
  list: {
    paddingLeft: "0px !important",
    paddingRight: "0px !important",
  },
}));

export default function MainContent() {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <div>
        <Typography className={classes.title}>Status</Typography>
        <Typography>open</Typography>
      </div>
      <div>
        <Typography className={classes.title}>Assignee</Typography>
        {/* <Avatar alt="Remy Sharp" className={classes.avatar} src={ss} />
        <Typography>Tom</Typography> */}
        <ListItem className={classes.list}>
          <ListItemAvatar>
            <Avatar
              alt="Remy Sharp"
              className={classes.avatar}
              src={ss}
            ></Avatar>
          </ListItemAvatar>
          <ListItemText primary="Tom" />
        </ListItem>
      </div>
      <div>
        <Typography className={classes.title}>Creator</Typography>
        {/* <Avatar alt="Remy Sharp" src={ss} /> */}
        <ListItem className={classes.list}>
          <ListItemAvatar>
            <Avatar
              alt="Remy Sharp"
              className={classes.avatar}
              src={ss}
            ></Avatar>
          </ListItemAvatar>
          <ListItemText primary="Jerry" />
        </ListItem>
      </div>
      <div>
        <Typography className={classes.title}>Owner</Typography>
        <Typography>None</Typography>
      </div>
      <Divider />
    </div>
  );
}
