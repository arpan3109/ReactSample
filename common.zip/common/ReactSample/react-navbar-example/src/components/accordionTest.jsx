import React, { Component } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "@material-ui/core/styles";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import Button from "@material-ui/core/Button";
import Avatar from "@material-ui/core/Avatar";
import Icon from "@material-ui/core/Icon";
import IconButton from "@material-ui/core/IconButton";
import FavoriteIcon from "@material-ui/icons/Favorite";
import AddBoxIcon from "@material-ui/icons/AddBox";
import ShareIcon from "@material-ui/icons/Share";
import Grid from "@material-ui/core/Grid";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ArrowDownwardIcon from "@material-ui/icons/ArrowDownward";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import InputLabel from "@material-ui/core/InputLabel";
import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import NativeSelect from "@material-ui/core/NativeSelect";
import ss from "./ArpanD.jpg";

// const useStyles = makeStyles((theme) => ({
//   root: {
//     width: "100%",
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     fontWeight: theme.typography.fontWeightRegular,
//   },
// }));

const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: 275,
    marginBottom: 5,
    backgroundColor: "#ede7f6",
  },
  bullet: {
    display: "inline-block",
    margin: "0 2px",
    transform: "scale(0.8)",
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
  avatar: {
    marginLeft: "auto",
    // border: "2px solid #eee",
    // marginLeft: 10,
    // padding: 1,
  },
  dropSelect: {
    width: "fit-content",
  },
  card: {
    margin: 10,
  },
  listItem: {
    textAlign: "right",
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const options = [
  "Show some love to Material-UI",
  "Show all notification content",
  "Hide sensitive notification content",
  "Hide all notification content",
];

export default function AccordionTest() {
  const sampleData = useSelector((state) => state);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [selectedIndex, setSelectedIndex] = React.useState(1);
  const [state, setState] = React.useState(Number);
  const handleChange = (event) => {
    const name = event.target.name;
    setState(event.target.value);
  };

  const handleClickListItem = (event) => {
    console.log(event.currentTarget);
    setAnchorEl(event.currentTarget);
  };

  const handleMenuItemClick = (event, index) => {
    console.log(index);
    setSelectedIndex(index);
    setAnchorEl(null);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const tempData = () => {
    console.log(3);
    setSelectedIndex(3);
    setState(10);
  };
  //   console.log(sampleData.books.allBooksData);
  //   const classes = useStyles();

  const classes = useStyles();
  const bull = <span className={classes.bullet}>•</span>;
  return (
    // <div className={classes.root}>
    //   {sampleData.books.allBooksData.length ? (
    //     sampleData.books.allBooksData.map((book) => (
    //       <Accordion key={book.id}>
    //         <AccordionSummary
    //           expandIcon={<ExpandMoreIcon />}
    //           aria-controls="panel1a-content"
    //           id="panel1a-header"
    //         >
    //           <Typography className={classes.heading}>
    //             {book.bookName}
    //           </Typography>
    //         </AccordionSummary>
    //         <AccordionDetails>
    //           <Typography>
    //             Lorem ipsum dolor sit amet, consectetur adipiscing elit.
    //             Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
    //             eget.
    //           </Typography>
    //         </AccordionDetails>
    //       </Accordion>
    //     ))
    //   ) : (
    //     <h1>Error</h1>
    //   )}
    // </div>

    <div className={classes.root}>
      <div className={classes.dropSelect}>
        <List component="nav" aria-label="Device settings">
          <ListItem
            button
            aria-haspopup="true"
            aria-controls="lock-menu"
            aria-label="when device is locked"
            onClick={handleClickListItem}
          >
            <ListItemText secondary={options[selectedIndex]} />
            <IconButton>
              <ExpandMoreIcon />
            </IconButton>
            {/* <IconButton className={classes.avatar}>
              <ArrowDownwardIcon />
            </IconButton> */}
          </ListItem>
        </List>

        <Menu
          id="lock-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          {options.map((option, index) => (
            <MenuItem
              key={option}
              disabled={index === 0}
              selected={index === selectedIndex}
              onClick={(event) => handleMenuItemClick(event, index)}
            >
              {option}
            </MenuItem>
          ))}
        </Menu>
      </div>
      <div>
        <FormControl variant="filled" className={classes.formControl}>
          <InputLabel htmlFor="filled-age-native-simple">Age</InputLabel>
          <Select
            native
            value={state}
            onChange={handleChange}
            inputProps={{
              name: "age",
              id: "filled-age-native-simple",
            }}
          >
            <option aria-label="None" value="" />
            <option value={10}>Ten</option>
            <option value={20}>Twenty</option>
            <option value={30}>Thirty</option>
          </Select>
        </FormControl>
      </div>
      {sampleData.books.allBooksData.length ? (
        sampleData.books.allBooksData.map((book) => (
          <Card className={classes.card} key={book.id} onClick={tempData}>
            <CardContent>
              <Typography variant="h5" component="h2">
                {book.author}: Read message
              </Typography>
            </CardContent>
            <CardActions disableSpacing>
              {/* <IconButton aria-label="add to favorites">
                <AddBoxIcon />
              </IconButton> */}
              <Typography className={classes.title} color="textSecondary">
                {/* <strong>{book.bookName}</strong> */}
                {book.bookName}
              </Typography>
              {/* <IconButton aria-label="share">
                  <ShareIcon />
                </IconButton> */}

              <ListItem className={classes.list}>
                {/* <ListItemAvatar></ListItemAvatar> */}
                <ListItemText className={classes.listItem} primary="Jerry" />
                <Avatar
                  alt="Remy Sharp"
                  className={classes.avatar}
                  src={ss}
                ></Avatar>
              </ListItem>

              {/* <Avatar alt="Remy Sharp" className={classes.avatar} src={ss} /> */}
            </CardActions>
          </Card>
        ))
      ) : (
        <h1>Error</h1>
      )}
    </div>
  );
}
