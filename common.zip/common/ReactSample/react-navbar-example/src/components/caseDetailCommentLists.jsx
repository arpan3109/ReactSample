import React, { Component } from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import Avatar from "@material-ui/core/Avatar";
import Paper from "@material-ui/core/Paper";
import ss from "./ArpanD.jpg";

const useStyles = makeStyles((theme) => ({
  root: {
    maxWidth: 400,
    borderRadius: "27%",
    backgroundColor: "#eee",
    marginLeft: "auto",
    padding: "2rem",
  },
  avatar: {
    marginLeft: "auto",
    marginBottom: "2rem",
  },
  root1: {
    maxWidth: 400,
    borderRadius: "27%",
    backgroundColor: "#eee",
    marginRight: "auto",
    padding: "2rem",
  },
  avatar1: {
    marginRight: "auto",
    marginBottom: "2rem",
    border: "2px solid #eee",
    padding: "2px",
  },
}));

export default function MainContent() {
  const classes = useStyles();
  const sampleData = useSelector((state) => state);
  return (
    <>
      <div>
        <Paper className={classes.root1}>
          {/* <Typography variant="body2" color="textSecondary" component="p"> */}
          This impressive paella is a perfect party dish and a fun meal to cook
          together with your guests. Add 1 cup of frozen peas along with the
          mussels, if you like.
          {/* </Typography> */}
        </Paper>
        <Avatar alt="Remy Sharp" className={classes.avatar1} src={ss} />
      </div>
      {sampleData.books.allBooksData.length ? (
        sampleData.books.allBooksData.map((book) => (
          <div key={book.id}>
            <Paper className={classes.root}>
              {/* <Typography variant="body2" color="textSecondary" component="p"> */}
              This impressive paella is a perfect party dish and a fun meal to
              cook together with your guests. Add 1 cup of frozen peas along
              with the mussels, if you like.
              {/* </Typography> */}
            </Paper>
            <Avatar alt="Remy Sharp" className={classes.avatar} src={ss} />
          </div>
        ))
      ) : (
        <h1>Error</h1>
      )}
    </>
  );
}
