import React from "react";
import { useSelector } from "react-redux";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Container from "@material-ui/core/Container";
import clsx from "clsx";
import Paper from "@material-ui/core/Paper";
import AccordionTest from "./accordionTest";
import CaseDetails from "./caseDetail";

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
  },
  menuButton: {
    marginRight: 36,
  },
  menuButtonHidden: {
    display: "none",
  },
  title: {
    flexGrow: 1,
  },
  appBarSpacer: theme.mixins.toolbar,
  content: {
    flexGrow: 1,
    height: "100vh",
  },
  container: {
    paddingTop: theme.spacing(1),
    paddingBottom: theme.spacing(1),
  },
  paper: {
    padding: theme.spacing(1),
    display: "flex",
    overflow: "auto",
    flexDirection: "column",
  },
  fixedHeight: {
    height: "80vh",
    overflow: "auto",
  },
  accordionSam: {
    height: "80vh",
    overflow: "auto",
  },
  caseDetails: {
    padding: theme.spacing(2),
  },
}));

export default function MainContent() {
  const classes = useStyles();
  const [open, setOpen] = React.useState(true);
  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };
  const fixedHeightPaper = clsx(classes.paper, classes.fixedHeight);
  const CaseDetailsPaper = clsx(
    classes.paper,
    classes.fixedHeight,
    classes.caseDetails
  );

  return (
    <div className={classes.root}>
      <main className={classes.content}>
        <div className={classes.appBarSpacer} />
        <Container maxWidth="lg" className={classes.container}>
          <Grid container spacing={1}>
            {/* Chart */}
            <Grid item xs={12} sm={6} md={4} lg={4}>
              <Paper>
                <div className={fixedHeightPaper}>
                  <AccordionTest />
                </div>
              </Paper>
            </Grid>
            {/* Recent Deposits */}
            <Grid item xs={12} sm={6} md={8} lg={8}>
              <div className={CaseDetailsPaper}>
                <CaseDetails />
              </div>
            </Grid>
            {/* Recent Orders */}
            {/* <Grid item xs={12}>
              <Paper className={classes.paper}></Paper>
            </Grid> */}
          </Grid>
        </Container>
      </main>
    </div>
  );
}
