import React from "react";
import { useState, useEffect, useRef } from "react";
const bookdataSam = {
  autor: [
    {
      id: "123",
      name: "abc",
      bookid: "5f07276005488f4008ee8472",
    },
    {
      id: "345",
      name: "cde",
      bookid: "5f07297a2f03495320ac2dd0",
    },
    {
      id: "456",
      name: "efg",
      bookid: "5f07276005488f4008ee8472",
    },
    {
      id: "6789",
      name: "ghi",
      bookid: "5f07276005488f4008ee8472",
    },
  ],
  book: [
    {
      id: "5f07276005488f4008ee8472",
      bookName: "Design Patterns",
      price: 54.93,
      category: "Computers",
      author: "Ralph Johnson",
    },
    {
      id: "5f07276005488f4008ee8472",
      bookName: "Stemmons pvt test",
      price: 140,
      category: "General",
      author: "nishant pradhan",
    },
    {
      id: "5f07297a2f03495320ac2dd0",
      bookName: "Clean Code",
      price: 43.15,
      category: "Computers",
      author: "Robert C. Martin",
    },
    {
      id: "5f1542a12dc4551a58bcc959",
      bookName: "Simple logic",
      price: 5,
      category: "SOCIAL",
      author: "Indian",
    },
    {
      id: "5f16bfd38a9b0555e86eb4da",
      bookName: "System",
      price: 4,
      category: "IT",
      author: "Developer",
    },
    {
      id: "5f16f7778a9b0555e86eb4e3",
      bookName: "Sample",
      price: 7,
      category: "General",
      author: "Public",
    },
    {
      id: "5f3e3b7cde8ce25d505c30b2",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e636be74a452ca0ed22",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e636be74a452ca0ed23",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e636be74a452ca0ed20",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e636be74a452ca0ed25",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e636be74a452ca0ed24",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e636be74a452ca0ed21",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e706be74a452ca0ed26",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
    {
      id: "5fa03e7f6be74a452ca0ed27",
      bookName: "Same data use",
      price: 78,
      category: "General",
      author: "human",
    },
  ],
};
function App1() {
  const isInitialMount = useRef(true);
  const [books, setbooks] = useState(bookdataSam);
  useEffect(() => {
    console.log("data");
  });
  console.log(books);
  let booksList =
    books.book.length > 0 &&
    books.book.map((item, i) => {
      return (
        <option key={i} value={item.id}>
          {item.id}
        </option>
      );
    }, this);

  let booksList1 =
    books.autor.length > 0 &&
    books.autor.map((item, i) => {
      return (
        <option key={item.id} value={item.id}>
          {item.id}
        </option>
      );
    }, this);
  function handleChange(event) {
    const bookdataSam1 = {
      autor: [
        {
          id: "4545",
          name: "abc",
          bookid: "5f07276005488f4008ee8472",
        },
        {
          id: "345",
          name: "cde",
          bookid: "5f07297a2f03495320ac2dd0",
        },
        {
          id: "456",
          name: "efg",
          bookid: "5f07276005488f4008ee8472",
        },
        {
          id: "6789",
          name: "ghi",
          bookid: "5f07276005488f4008ee8472",
        },
      ],
      book: [
        {
          id: "5f07276005488f4008ee8472",
          bookName: "Design Patterns",
          price: 54.93,
          category: "Computers",
          author: "Ralph Johnson",
        },
        {
          id: "5f07276005488f4008ee8472",
          bookName: "Stemmons pvt test",
          price: 140,
          category: "General",
          author: "nishant pradhan",
        },
        {
          id: "5f07297a2f03495320ac2dd0",
          bookName: "Clean Code",
          price: 43.15,
          category: "Computers",
          author: "Robert C. Martin",
        },
        {
          id: "5f1542a12dc4551a58bcc959",
          bookName: "Simple logic",
          price: 5,
          category: "SOCIAL",
          author: "Indian",
        },
        {
          id: "5f16bfd38a9b0555e86eb4da",
          bookName: "System",
          price: 4,
          category: "IT",
          author: "Developer",
        },
        {
          id: "5f16f7778a9b0555e86eb4e3",
          bookName: "Sample",
          price: 7,
          category: "General",
          author: "Public",
        },
        {
          id: "5f3e3b7cde8ce25d505c30b2",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e636be74a452ca0ed22",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e636be74a452ca0ed23",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e636be74a452ca0ed20",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e636be74a452ca0ed25",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e636be74a452ca0ed24",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e636be74a452ca0ed21",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e706be74a452ca0ed26",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
        {
          id: "5fa03e7f6be74a452ca0ed27",
          bookName: "Same data use",
          price: 78,
          category: "General",
          author: "human",
        },
      ],
    };
    setbooks(bookdataSam1);
  }
  return (
    <div className="mt-5">
      <h1>Hello</h1>
      <select onChange={handleChange}>{booksList}</select>
      <select>
        <option value="1" disabled>
          Select
        </option>
        {booksList1}
      </select>
    </div>
  );
}

export default App1;
