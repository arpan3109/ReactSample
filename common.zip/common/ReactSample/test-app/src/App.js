import React, { Component } from "react";
import axios from "axios";
import "./App.css";

const API = `http://10.17.3.182:82/api/books`;
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      books: [],
      keys: [],
      next: [],
      errorMeaage: "",
    };
    this.selectBook = this.selectBook.bind(this);
  }
  componentDidMount() {
    console.log("componentDidMount");
    this.apiGetRequest(API);
  }
  componentDidUpdate(prevProps, prevState) {
    console.log("componentDidUpdate");
    if (prevState.books.length !== this.state.books.length) {
      console.log("Books state has changed.");
      this.apiGetRequest(API);
    }
  }

  apiGetRequest = function (API) {
    console.log("apiGetRequest");
    axios.get(API).then((res) => {
      const books = res.data;
      this.setState({ books: books });
      this.setState({ keys: Object.keys(this.state.books[0]) });
    });
  };

  selectBook = (e) => {
    console.log("Selected dropdown value is " + e.target.value);
    axios.get(API).then((res) => {
      const books = res.data;
      this.setState({ next: books });
      console.log("this.state.next apiGetRequestFor" + this.state.next);
    });
  };

  render() {
    const { books, next } = this.state;

    let booksList =
      books.length > 0 &&
      books.map((item, i) => {
        return (
          <option key={i} value={item.id}>
            {item.id}
          </option>
        );
      }, this);

    let booksList1 =
      next.length > 0 &&
      next.map((item, i) => {
        return (
          <option key={i} value={item.id}>
            {item.id}
          </option>
        );
      }, this);

    return (
      <div className="mt-5">
        <h1>Hello</h1>
        <select onChange={this.selectBook}>{booksList}</select>
        <select>
          <option value="1" disabled>
            Select
          </option>
          {booksList1}
        </select>
      </div>
    );
  }
}

export default App;
