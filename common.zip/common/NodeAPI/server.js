var express = require("express");
var app = express();
var port = process.env.port || 8000;

// var loginController = require("./Controller/LoginController");
var userController = require("./Controller/UserController")();

// app.get("/about", function (request, response) {
//   response.json({ Message: "this is all about us" });
// });

// app.use("/api/login", loginController);
app.use("/api/user", userController);

app.listen(port, function () {
  var datetime = new Date();
  var message =
    "Server rinning on port:- " + port + " started at :- " + datetime;
  console.log(message);
});
