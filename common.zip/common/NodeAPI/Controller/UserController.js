var express = require("express");
var router = express.Router();
var sql = require("mssql");
var conn = require("../connection/connect")();

var routes = function () {
  router.route("/").get(function (req, res) {
    console.log("routes initial ");
    conn
      .connect()
      .then(function () {
        console.log("req");
        var sqlQuery = "SELECT * FROM LoginsData";

        var req = new sql.Request(conn);

        req
          .query(sqlQuery)
          .then(function (recordset) {
            console.log(recordset);
            res.json(recordset.recordset);
            conn.close();
          })
          .catch(function (err) {
            conn.close();
            res.status(400).send("Error while inserting data 1", err);
          });
      })
      .catch(function (err) {
        conn.close();
        res.status(400).send("Error while inserting data 2");
      });
  });
  return router;
};

module.exports = routes;
