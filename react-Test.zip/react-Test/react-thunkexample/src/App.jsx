import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {fetchPosts} from './action';
import GraphCom from "./graphCom";



function App() {
    const dispatch= useDispatch();
    const state = useSelector(state => state);
    useEffect(() => {
        dispatch(fetchPosts());
    }, [])
    console.log("state",state);
    const renderPoste=()=>{
        if(state.loading){
            return <h1>Loading...</h1>
        }
        return state.items.map((post)=>{return <div key={post.id}><h1>{post.userId}</h1><h4>{post.title}</h4><p>{post.body}</p></div>})
    }
    return (
        <div>
            {/* {renderPoste()} */}
            <GraphCom/>
        </div>
    )
}

export default App
